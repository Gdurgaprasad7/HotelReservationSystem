import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 * Hotel Reservation System (console-based)
 *
 * OOP design : RoomCategory (enum), Room, Booking, HotelRepository, PaymentService, ConsoleUI
 * Features   : search rooms by dates/category, book, cancel (with refund policy),
 *              payment simulation (card / UPI / pay-at-hotel), booking details view, admin report
 * Storage    : plain CSV files in ./hotel_data/  (rooms.csv, bookings.csv) - no external libraries
 *
 * Run:  javac HotelReservationSystem.java && java HotelReservationSystem
 */
public class HotelReservationSystem {

    // =====================================================================
    //  MODEL
    // =====================================================================

    /** Room categories with their price, capacity and amenities. */
    enum RoomCategory {
        STANDARD("Standard", 2000, 2, "AC, TV, Wi-Fi"),
        DELUXE("Deluxe", 3500, 3, "AC, TV, Wi-Fi, Mini-bar, City view"),
        SUITE("Suite", 6000, 4, "AC, TV, Wi-Fi, Mini-bar, Living area, Bathtub, Breakfast");

        final String label;
        final double pricePerNight;
        final int capacity;
        final String amenities;

        RoomCategory(String label, double pricePerNight, int capacity, String amenities) {
            this.label = label;
            this.pricePerNight = pricePerNight;
            this.capacity = capacity;
            this.amenities = amenities;
        }
    }

    static class Room {
        private final int number;
        private final RoomCategory category;

        Room(int number, RoomCategory category) {
            this.number = number;
            this.category = category;
        }

        int getNumber() { return number; }
        RoomCategory getCategory() { return category; }
        String toCsv() { return number + "," + category.name(); }

        static Room fromCsv(String line) {
            String[] p = line.split(",", -1);
            return new Room(Integer.parseInt(p[0].trim()), RoomCategory.valueOf(p[1].trim()));
        }
    }

    enum Status { CONFIRMED, CANCELLED }

    static class Booking {
        private final String id;
        private final String guestName;
        private final String phone;
        private final int roomNumber;
        private final LocalDate checkIn;
        private final LocalDate checkOut;
        private final int guests;
        private final double totalAmount;
        private final String paymentMethod;
        private final String transactionId;
        private final LocalDateTime createdAt;
        private Status status;
        private double refundAmount;

        Booking(String id, String guestName, String phone, int roomNumber, LocalDate checkIn, LocalDate checkOut,
                int guests, double totalAmount, String paymentMethod, String transactionId,
                Status status, double refundAmount, LocalDateTime createdAt) {
            this.id = id;
            this.guestName = guestName;
            this.phone = phone;
            this.roomNumber = roomNumber;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.guests = guests;
            this.totalAmount = totalAmount;
            this.paymentMethod = paymentMethod;
            this.transactionId = transactionId;
            this.status = status;
            this.refundAmount = refundAmount;
            this.createdAt = createdAt;
        }

        String getId() { return id; }
        String getGuestName() { return guestName; }
        String getPhone() { return phone; }
        int getRoomNumber() { return roomNumber; }
        LocalDate getCheckIn() { return checkIn; }
        LocalDate getCheckOut() { return checkOut; }
        int getGuests() { return guests; }
        double getTotalAmount() { return totalAmount; }
        String getPaymentMethod() { return paymentMethod; }
        String getTransactionId() { return transactionId; }
        Status getStatus() { return status; }
        double getRefundAmount() { return refundAmount; }
        LocalDateTime getCreatedAt() { return createdAt; }
        long nights() { return ChronoUnit.DAYS.between(checkIn, checkOut); }
        boolean isConfirmed() { return status == Status.CONFIRMED; }

        void cancel(double refund) {
            this.status = Status.CANCELLED;
            this.refundAmount = refund;
        }

        /** True if this booking's stay overlaps [in, out). Check-out day is free for the next guest. */
        boolean overlaps(LocalDate in, LocalDate out) {
            return checkIn.isBefore(out) && in.isBefore(checkOut);
        }

        String toCsv() {
            return String.join(",", id, guestName.replace(",", " "), phone, String.valueOf(roomNumber),
                    checkIn.toString(), checkOut.toString(), String.valueOf(guests),
                    String.valueOf(totalAmount), paymentMethod, transactionId,
                    status.name(), String.valueOf(refundAmount), createdAt.toString());
        }

        static Booking fromCsv(String line) {
            String[] p = line.split(",", -1);
            return new Booking(p[0], p[1], p[2], Integer.parseInt(p[3]), LocalDate.parse(p[4]),
                    LocalDate.parse(p[5]), Integer.parseInt(p[6]), Double.parseDouble(p[7]), p[8], p[9],
                    Status.valueOf(p[10]), Double.parseDouble(p[11]), LocalDateTime.parse(p[12]));
        }
    }

    // =====================================================================
    //  STORAGE (File I/O)
    // =====================================================================

    static class HotelRepository {
        private final Path dir;
        private final Path roomsFile;
        private final Path bookingsFile;
        private final List<Room> rooms = new ArrayList<>();
        private final List<Booking> bookings = new ArrayList<>();

        HotelRepository(String directory) {
            this.dir = Paths.get(directory);
            this.roomsFile = dir.resolve("rooms.csv");
            this.bookingsFile = dir.resolve("bookings.csv");
            load();
        }

        private void load() {
            try {
                Files.createDirectories(dir);
                if (!Files.exists(roomsFile)) seedRooms();
                for (String line : Files.readAllLines(roomsFile, StandardCharsets.UTF_8))
                    if (!line.trim().isEmpty()) rooms.add(Room.fromCsv(line));
                if (Files.exists(bookingsFile))
                    for (String line : Files.readAllLines(bookingsFile, StandardCharsets.UTF_8))
                        if (!line.trim().isEmpty()) bookings.add(Booking.fromCsv(line));
            } catch (IOException | RuntimeException e) {
                System.out.println("Warning: could not read data files (" + e.getMessage() + ").");
            }
        }

        /** Creates the default hotel inventory the first time the program runs. */
        private void seedRooms() throws IOException {
            List<String> lines = new ArrayList<>();
            for (int i = 101; i <= 105; i++) lines.add(new Room(i, RoomCategory.STANDARD).toCsv());
            for (int i = 201; i <= 204; i++) lines.add(new Room(i, RoomCategory.DELUXE).toCsv());
            for (int i = 301; i <= 302; i++) lines.add(new Room(i, RoomCategory.SUITE).toCsv());
            Files.write(roomsFile, lines, StandardCharsets.UTF_8);
        }

        void saveBookings() {
            List<String> lines = new ArrayList<>();
            for (Booking b : bookings) lines.add(b.toCsv());
            try {
                Files.write(bookingsFile, lines, StandardCharsets.UTF_8);
            } catch (IOException e) {
                System.out.println("ERROR: could not save bookings: " + e.getMessage());
            }
        }

        List<Room> getRooms() { return rooms; }
        List<Booking> getBookings() { return bookings; }

        Room findRoom(int number) {
            for (Room r : rooms) if (r.getNumber() == number) return r;
            return null;
        }

        Booking findBooking(String id) {
            for (Booking b : bookings) if (b.getId().equalsIgnoreCase(id)) return b;
            return null;
        }

        boolean isAvailable(Room room, LocalDate in, LocalDate out) {
            for (Booking b : bookings)
                if (b.isConfirmed() && b.getRoomNumber() == room.getNumber() && b.overlaps(in, out)) return false;
            return true;
        }

        List<Room> searchAvailable(LocalDate in, LocalDate out, RoomCategory category, int guests) {
            List<Room> result = new ArrayList<>();
            for (Room r : rooms) {
                if (category != null && r.getCategory() != category) continue;
                if (r.getCategory().capacity < guests) continue;
                if (isAvailable(r, in, out)) result.add(r);
            }
            return result;
        }

        String nextBookingId() {
            int max = 1000;
            for (Booking b : bookings) {
                try {
                    max = Math.max(max, Integer.parseInt(b.getId().substring(2)));
                } catch (RuntimeException ignored) { }
            }
            return "BK" + (max + 1);
        }

        void addBooking(Booking b) {
            bookings.add(b);
            saveBookings();
        }
    }

    // =====================================================================
    //  PAYMENT SIMULATION
    // =====================================================================

    static class PaymentResult {
        final boolean success;
        final String transactionId;
        final String message;

        PaymentResult(boolean success, String transactionId, String message) {
            this.success = success;
            this.transactionId = transactionId;
            this.message = message;
        }
    }

    static class PaymentService {
        static PaymentResult payByCard(double amount, String cardNumber, String expiry, String cvv) {
            String digits = cardNumber.replaceAll("[\\s-]", "");
            if (!digits.matches("\\d{16}") || !luhnValid(digits))
                return new PaymentResult(false, "-", "Invalid card number.");
            if (!cvv.matches("\\d{3}"))
                return new PaymentResult(false, "-", "Invalid CVV.");
            try {
                YearMonth exp = YearMonth.parse(expiry, DateTimeFormatter.ofPattern("MM/yy"));
                if (exp.isBefore(YearMonth.now()))
                    return new PaymentResult(false, "-", "Card has expired.");
            } catch (DateTimeParseException e) {
                return new PaymentResult(false, "-", "Invalid expiry date (use MM/YY).");
            }
            simulateProcessing();
            if (digits.endsWith("0000"))
                return new PaymentResult(false, "-", "Payment declined by bank (simulated).");
            return new PaymentResult(true, "TXN" + shortId(), "Card payment of Rs. " + fmt(amount) + " successful.");
        }

        static PaymentResult payByUpi(double amount, String upiId) {
            if (!upiId.matches("[\\w.\\-]{2,}@[a-zA-Z]{2,}"))
                return new PaymentResult(false, "-", "Invalid UPI ID (example: name@bank).");
            simulateProcessing();
            return new PaymentResult(true, "UPI" + shortId(), "UPI payment of Rs. " + fmt(amount) + " successful.");
        }

        static PaymentResult payAtHotel() {
            return new PaymentResult(true, "PAY-AT-HOTEL", "Room reserved. Please pay at the front desk on arrival.");
        }

        /** Luhn checksum - the same check real card numbers use. */
        static boolean luhnValid(String digits) {
            int sum = 0;
            boolean dbl = false;
            for (int i = digits.length() - 1; i >= 0; i--) {
                int d = digits.charAt(i) - '0';
                if (dbl) { d *= 2; if (d > 9) d -= 9; }
                sum += d;
                dbl = !dbl;
            }
            return sum % 10 == 0;
        }

        private static void simulateProcessing() {
            System.out.print("Processing payment");
            for (int i = 0; i < 3; i++) {
                try { Thread.sleep(350); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                System.out.print(".");
            }
            System.out.println();
        }

        private static String shortId() { return UUID.randomUUID().toString().substring(0, 8).toUpperCase(); }
    }

    // =====================================================================
    //  HELPERS
    // =====================================================================

    static String fmt(double v) { return String.format("%,.2f", v); }

    /** Refund policy: 2+ days before check-in = 100%, less than 2 days = 50%, pay-at-hotel = nothing to refund. */
    static double refundFor(Booking b, LocalDate today) {
        if (b.getPaymentMethod().equals("PAY-AT-HOTEL")) return 0;
        long days = ChronoUnit.DAYS.between(today, b.getCheckIn());
        return days >= 2 ? b.getTotalAmount() : b.getTotalAmount() * 0.5;
    }

    // =====================================================================
    //  CONSOLE UI
    // =====================================================================

    static class ConsoleUI {
        private final HotelRepository repo;
        private final Scanner in = new Scanner(System.in);

        ConsoleUI(HotelRepository repo) { this.repo = repo; }

        void run() {
            System.out.println("==========================================");
            System.out.println("        GRAND JAVA HOTEL - RESERVATIONS");
            System.out.println("==========================================");
            boolean running = true;
            while (running) {
                System.out.println("\n--- MAIN MENU ---");
                System.out.println("1. Search available rooms");
                System.out.println("2. Book a room");
                System.out.println("3. View booking details");
                System.out.println("4. Cancel a booking");
                System.out.println("5. Find my bookings (by phone)");
                System.out.println("6. Room categories & rates");
                System.out.println("7. Admin report");
                System.out.println("0. Exit");
                switch (readInt("Choose an option: ", 0, 7)) {
                    case 1: searchRooms(); break;
                    case 2: bookRoom(); break;
                    case 3: viewBooking(); break;
                    case 4: cancelBooking(); break;
                    case 5: findByPhone(); break;
                    case 6: showCategories(); break;
                    case 7: adminReport(); break;
                    case 0: running = false; break;
                    default: break;
                }
            }
            System.out.println("Thank you for visiting. Goodbye!");
        }

        // ---------- Search ----------
        private void searchRooms() {
            LocalDate today = LocalDate.now();
            LocalDate checkIn = readDate("Check-in date (yyyy-MM-dd): ", today);
            LocalDate checkOut = readDate("Check-out date (yyyy-MM-dd): ", checkIn.plusDays(1));
            int guests = readInt("Number of guests (1-4): ", 1, 4);
            RoomCategory cat = readCategory(true);
            List<Room> available = repo.searchAvailable(checkIn, checkOut, cat, guests);
            printAvailable(available, checkIn, checkOut);
        }

        private void printAvailable(List<Room> available, LocalDate checkIn, LocalDate checkOut) {
            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
            if (available.isEmpty()) {
                System.out.println("\nSorry, no rooms are available for those dates/criteria.");
                return;
            }
            System.out.println("\nAvailable rooms for " + checkIn + " to " + checkOut + " (" + nights + " night(s)):");
            System.out.printf("%-6s %-10s %-6s %-12s %-12s %s%n", "Room", "Category", "Sleeps", "Per night", "Total", "Amenities");
            System.out.println("-----------------------------------------------------------------------------");
            for (Room r : available) {
                RoomCategory c = r.getCategory();
                System.out.printf("%-6d %-10s %-6d Rs.%-9s Rs.%-9s %s%n", r.getNumber(), c.label, c.capacity,
                        fmt(c.pricePerNight), fmt(c.pricePerNight * nights), c.amenities);
            }
        }

        // ---------- Book ----------
        private void bookRoom() {
            LocalDate today = LocalDate.now();
            LocalDate checkIn = readDate("Check-in date (yyyy-MM-dd): ", today);
            LocalDate checkOut = readDate("Check-out date (yyyy-MM-dd): ", checkIn.plusDays(1));
            int guests = readInt("Number of guests (1-4): ", 1, 4);
            RoomCategory cat = readCategory(true);

            List<Room> available = repo.searchAvailable(checkIn, checkOut, cat, guests);
            printAvailable(available, checkIn, checkOut);
            if (available.isEmpty()) return;

            Room room = null;
            while (room == null) {
                int num = readInt("\nEnter room number to book (0 to cancel): ", 0, 9999);
                if (num == 0) { System.out.println("Booking cancelled."); return; }
                for (Room r : available) if (r.getNumber() == num) room = r;
                if (room == null) System.out.println("That room isn't in the list above.");
            }

            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
            double total = room.getCategory().pricePerNight * nights;

            String name = readNonEmpty("Guest name: ");
            String phone = readPhone("Phone number (10 digits): ");

            System.out.println("\nAmount payable: Rs. " + fmt(total));
            PaymentResult result = collectPayment(total);
            if (result == null) { System.out.println("Booking not completed."); return; }

            // Re-check availability right before saving (safety against double booking)
            if (!repo.isAvailable(room, checkIn, checkOut)) {
                System.out.println("Sorry, that room was just taken. Booking not saved.");
                return;
            }
            Booking b = new Booking(repo.nextBookingId(), name, phone, room.getNumber(), checkIn, checkOut, guests,
                    total, methodName, result.transactionId, Status.CONFIRMED, 0, LocalDateTime.now());
            repo.addBooking(b);
            System.out.println("\n" + result.message);
            System.out.println("Booking confirmed!");
            printBooking(b);
        }

        private String methodName = "";

        /** Returns a successful PaymentResult, or null if the user gives up. */
        private PaymentResult collectPayment(double amount) {
            while (true) {
                System.out.println("Payment method: 1) Credit/Debit card  2) UPI  3) Pay at hotel  0) Abort");
                int choice = readInt("Choose: ", 0, 3);
                PaymentResult r;
                switch (choice) {
                    case 1:
                        methodName = "CARD";
                        System.out.println("(Demo cards: 4111 1111 1111 1111 = success, 4000 0000 0002 0000 = declined.)");
                        r = PaymentService.payByCard(amount, readNonEmpty("Card number: "),
                                readNonEmpty("Expiry (MM/YY): "), readNonEmpty("CVV: "));
                        break;
                    case 2:
                        methodName = "UPI";
                        r = PaymentService.payByUpi(amount, readNonEmpty("UPI ID: "));
                        break;
                    case 3:
                        methodName = "PAY-AT-HOTEL";
                        r = PaymentService.payAtHotel();
                        break;
                    default:
                        return null;
                }
                if (r.success) return r;
                System.out.println("Payment failed: " + r.message);
            }
        }

        // ---------- View / find ----------
        private void viewBooking() {
            Booking b = repo.findBooking(readNonEmpty("Enter booking ID (e.g. BK1001): "));
            if (b == null) System.out.println("No booking found with that ID.");
            else printBooking(b);
        }

        private void findByPhone() {
            String phone = readPhone("Phone number used for booking: ");
            boolean any = false;
            System.out.printf("%n%-8s %-10s %-6s %-12s %-12s %-10s%n", "ID", "Guest", "Room", "Check-in", "Check-out", "Status");
            for (Booking b : repo.getBookings()) {
                if (b.getPhone().equals(phone)) {
                    any = true;
                    System.out.printf("%-8s %-10s %-6d %-12s %-12s %-10s%n", b.getId(),
                            b.getGuestName().length() > 10 ? b.getGuestName().substring(0, 10) : b.getGuestName(),
                            b.getRoomNumber(), b.getCheckIn(), b.getCheckOut(), b.getStatus());
                }
            }
            if (!any) System.out.println("No bookings found for that number.");
        }

        private void printBooking(Booking b) {
            Room room = repo.findRoom(b.getRoomNumber());
            String line = "+------------------------------------------------+";
            System.out.println("\n" + line);
            System.out.println("|                 BOOKING DETAILS                |");
            System.out.println(line);
            row("Booking ID", b.getId());
            row("Status", b.getStatus().name());
            row("Guest", b.getGuestName());
            row("Phone", b.getPhone());
            row("Room", b.getRoomNumber() + " (" + (room != null ? room.getCategory().label : "?") + ")");
            row("Check-in", b.getCheckIn().toString());
            row("Check-out", b.getCheckOut().toString());
            row("Nights", String.valueOf(b.nights()));
            row("Guests", String.valueOf(b.getGuests()));
            row("Total", "Rs. " + fmt(b.getTotalAmount()));
            row("Payment", b.getPaymentMethod());
            row("Transaction", b.getTransactionId());
            if (b.getStatus() == Status.CANCELLED) row("Refund", "Rs. " + fmt(b.getRefundAmount()));
            row("Booked on", b.getCreatedAt().toLocalDate().toString());
            System.out.println(line);
        }

        private void row(String label, String value) {
            System.out.printf("| %-12s : %-30s |%n", label, value.length() > 30 ? value.substring(0, 30) : value);
        }

        // ---------- Cancel ----------
        private void cancelBooking() {
            Booking b = repo.findBooking(readNonEmpty("Enter booking ID to cancel: "));
            if (b == null) { System.out.println("No booking found with that ID."); return; }
            if (!b.isConfirmed()) { System.out.println("That booking is already cancelled."); return; }
            LocalDate today = LocalDate.now();
            if (b.getCheckIn().isBefore(today)) {
                System.out.println("This stay has already started/finished and can no longer be cancelled.");
                return;
            }
            String phone = readPhone("Verify with the phone number on the booking: ");
            if (!phone.equals(b.getPhone())) { System.out.println("Phone number does not match. Cancellation denied."); return; }

            double refund = refundFor(b, today);
            System.out.println("\nCancellation policy: 2+ days before check-in = full refund, otherwise 50%.");
            System.out.println("Refund you will receive: Rs. " + fmt(refund));
            if (!readNonEmpty("Confirm cancellation? (y/n): ").equalsIgnoreCase("y")) {
                System.out.println("Cancellation aborted. Your booking is unchanged.");
                return;
            }
            b.cancel(refund);
            repo.saveBookings();
            System.out.println("Booking " + b.getId() + " cancelled. "
                    + (refund > 0 ? "Rs. " + fmt(refund) + " will be refunded to your original payment method (simulated)." : ""));
        }

        // ---------- Info ----------
        private void showCategories() {
            System.out.println("\nRoom categories:");
            for (RoomCategory c : RoomCategory.values()) {
                int count = 0;
                for (Room r : repo.getRooms()) if (r.getCategory() == c) count++;
                System.out.printf(" %-9s Rs.%-8s/night | sleeps %d | %d rooms | %s%n",
                        c.label, fmt(c.pricePerNight), c.capacity, count, c.amenities);
            }
        }

        private void adminReport() {
            LocalDate today = LocalDate.now();
            int occupied = 0, confirmed = 0, cancelled = 0;
            double revenue = 0;
            for (Booking b : repo.getBookings()) {
                if (b.isConfirmed()) {
                    confirmed++;
                    revenue += b.getTotalAmount();
                } else {
                    cancelled++;
                    revenue += b.getTotalAmount() - b.getRefundAmount();
                }
            }
            for (Room r : repo.getRooms())
                if (!repo.isAvailable(r, today, today.plusDays(1))) occupied++;

            System.out.println("\n--- ADMIN REPORT (" + today + ") ---");
            System.out.println("Total rooms        : " + repo.getRooms().size());
            System.out.println("Occupied tonight   : " + occupied);
            System.out.println("Free tonight       : " + (repo.getRooms().size() - occupied));
            System.out.println("Confirmed bookings : " + confirmed);
            System.out.println("Cancelled bookings : " + cancelled);
            System.out.println("Net booking value  : Rs. " + fmt(revenue));
            System.out.println("\nAll bookings:");
            if (repo.getBookings().isEmpty()) System.out.println(" (none)");
            for (Booking b : repo.getBookings())
                System.out.printf(" %-7s room %-4d %s -> %s  %-9s Rs.%s%n", b.getId(), b.getRoomNumber(),
                        b.getCheckIn(), b.getCheckOut(), b.getStatus(), fmt(b.getTotalAmount()));
        }

        // ---------- Input helpers ----------
        private String readLine(String prompt) {
            System.out.print(prompt);
            if (!in.hasNextLine()) { System.out.println("\nInput ended. Goodbye!"); System.exit(0); }
            return in.nextLine().trim();
        }

        private String readNonEmpty(String prompt) {
            while (true) {
                String s = readLine(prompt);
                if (!s.isEmpty()) return s;
                System.out.println("Input cannot be empty.");
            }
        }

        private int readInt(String prompt, int min, int max) {
            while (true) {
                try {
                    int v = Integer.parseInt(readLine(prompt));
                    if (v >= min && v <= max) return v;
                } catch (NumberFormatException ignored) { }
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            }
        }

        private String readPhone(String prompt) {
            while (true) {
                String s = readLine(prompt);
                if (s.matches("\\d{10}")) return s;
                System.out.println("Phone number must be exactly 10 digits.");
            }
        }

        private LocalDate readDate(String prompt, LocalDate min) {
            while (true) {
                try {
                    LocalDate d = LocalDate.parse(readLine(prompt));
                    if (!d.isBefore(min)) return d;
                    System.out.println("Date must be " + min + " or later.");
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date. Use the format yyyy-MM-dd (e.g. 2026-12-25).");
                }
            }
        }

        private RoomCategory readCategory(boolean allowAny) {
            System.out.println("Category: 1) Standard  2) Deluxe  3) Suite" + (allowAny ? "  4) Any" : ""));
            int c = readInt("Choose: ", 1, allowAny ? 4 : 3);
            return c == 4 ? null : RoomCategory.values()[c - 1];
        }
    }

    // =====================================================================
    //  ENTRY POINT
    // =====================================================================
    public static void main(String[] args) {
        new ConsoleUI(new HotelRepository("hotel_data")).run();
    }
}
