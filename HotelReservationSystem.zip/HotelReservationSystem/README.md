# Hotel Reservation System (Eclipse project)

Console-based Java app: search/book/cancel rooms, payment simulation, booking details, CSV storage.

## Import into Eclipse
File > Import... > General > Existing Projects into Workspace > select this folder (or the .zip) > Finish

## Run
Right-click src/HotelReservationSystem.java > Run As > Java Application.
Type your input in Eclipse's Console tab (click inside it first).

Data is saved in hotel_data/ (rooms.csv, bookings.csv) in the project root. Refresh the project to see it.
Demo cards: 4111 1111 1111 1111 = success, 4000 0000 0002 0000 = declined.
Requires JDK 11 or newer.
